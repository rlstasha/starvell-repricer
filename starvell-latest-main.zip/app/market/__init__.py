"""Market API adapter package."""

