"""Core configuration and logging."""

